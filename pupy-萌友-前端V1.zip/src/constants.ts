import { Pet, Realm } from './types';

export const PETS: Pet[] = [
  {
    id: '1',
    name: 'Cooper',
    age: 2,
    breed: '金毛寻回犬',
    mbti: 'ENFP',
    tags: ['活泼', '社交达人', '接球高手'],
    distance: '2km',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_EHfBjct31HQ4X7wg40_TQPmltQrC3u-Pgf1Yph077_IaRvF4glEocbvaXsE6EX46imagDtPZV6Zk-WQYYAGABNC-lEOBQKkTk-sBk1ThWEvOdPlSFhVuD7_ga4m11uoPYkcOjgwydmVYEihTVXWYEfGeghnNSTpPz9jSWoifKFwQyLDzQEycIwsyOfH867Op7kGaedCmpuRMn0NdIvH6HVDIbNSL7H5lFs9K9Y59YFUIsc8A1So7Ar6WbDapKsOSjMs_M2rICag',
    ownerAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBhmUZfRryut4QZLEJGQUze4phBcJK955viDZlcxG-g9tMr4S4vLjxPhai6UfCdOjjEKkKiJdO6LeyJPWQutwtOa6B4ho_KNw__UDOb_pifmmm4th8nBIy-jv7eIEdDjsyxUUVIqjog48UwiSaNyAKoEw_kkKmvjXT3xzvphseVWbKiwA98cnb7brGwh51OANhzxlwv1XlWEZm7nUUhqfx2Af67X7RaahebRczjFvhk8wvViFGI-mpjeE3LpJgEB1rAS2VwCj9ypqw',
    ownerName: '想喝咖啡吗？'
  },
  {
    id: '2',
    name: 'Mochi',
    age: 1,
    breed: '柴犬',
    mbti: 'INFP',
    tags: ['安静', '治愈系', '爱笑'],
    distance: '500m',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDxD_f1rYqSNAZTHpEhXBj1u-5FpueLDJ_MTwYAn5vBWMIhLy1fBgbD8BpoQ2pidl69P1gsYQvlWvq4FjnnxhJXrhFTTaCJabcL7DMx5ugz0KACNFlWm4FqdWGjGKlTpajQBus0sUo29yJ4aC06wZn6_70SahaoRn9SHqVl77N7qdHqYU0GqMFGEttVHgm-KkMngA9G01e2fYwL9M_ySvp3IC1O3MSv-VfRZccvbZZpSt38pio4vHYucOYL7AkAgcivHViOZ0QQwL8',
    ownerAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAUTZA1McDtSDu2NrkokujtmavcutZIEn1UIRuFMYGnOMVjohbVWNPHdChlcN6Z2DL3RMqmOZfvoKBBr19IR-pM678fN92sIU3JoljPHHgnrf14nCskBkXQmhlsxW6Dt3cEkyJPGwG_CxN__693L4f3o3WnPjz9krqZl3zjy3Kiv5-ANNPADplM_cDTcmufT1nQx3_nVN-g9rmqFZC7WlQWLU9Q0_5yGOLYBf4A49C51enLbeky6zs_qiea2ktePhflA7abkNs_WfQ',
    ownerName: 'Elena'
  }
];

export const REALMS: Realm[] = [
  {
    id: 'misty-forest',
    name: '迷雾森林',
    description: '清晨的魔法松林，治愈光芒洒满大地。',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBvTsqwGctm0uy_fOEsTVq9vZv2Ce8p40HN0zn648q1RQWh-63OtROTb1fs3X-JNc7maxuZEbl-ElrFk-L7dJ_emKwgjEAueC4Q9pWQV8mIPpJIFzkr3Tq-4wtln6BzSvbdiksIBn5B2n6OVJ-WQPJw_hQG5rzek127SyTQ9WlLMcF3AQ7GWAedm3QTisfabtw9iyDl1kLdduWpRjgVgpYmILNjxr6KcgDOgybcw3Ur8OdUs9-XqAGrrpwC1U0P2Y3IhfVw3Mct0Hk',
    onlineCount: 120,
    icon: 'explore',
    active: true
  },
  {
    id: 'deep-sea',
    name: '深海宝藏',
    description: '发光的珊瑚礁与古老沉船，奇幻的海底世界。',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA-cwTkI8aSoKBwi9u7DD4Pek6w9nv46eiAFbZKch4aaXsIpalKSczQZp18xzgfYIQRVAUHtPsgLOKTbVt21uBZst7bOBdLQFh8sTyUmyAubiR25j8poPidpGJNZ7HtDE0HflbeaB9xa9Mr65HpzwBhvR40mgn8iVBPd56qE4SG0dWF1TtYGWzQe-FB3kRyywYg0D6GRH-wP8w28GH47XesGgHb-ijq40unx5vOVb814K_RCXS05Gj7s3zNw_IyjuB111svjhXdpGg',
    onlineCount: 85,
    icon: 'sailing'
  },
  {
    id: 'neon-city',
    name: '霓虹都市',
    description: '赛博朋克风格的未来都市，充满活力的夜晚。',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCeske6YYlH0KPcQYdN4WDmcUGE8MofqJtT9U3Q41DvMc97whHKudeYorbzRWVj-cfL8IynCQVfzQ8iqgZT3QMPIOM7LrNzW4Qrccnm4oL21XwyQBcncWMFdhPKjm0ggBjsoimhiXxz6w-W-aACogXG6Eps-GA_DnbfioR0rYm9sFkEkEs6C3HQurq9VCseenON215_mtnIpQ9UC5eRjbtW-MHu_srklClgqIWeUyhQjdWUT04Do17qk6rKj4_d2jQaIW48O5TrbGg',
    onlineCount: 200,
    icon: 'nightlife'
  }
];
