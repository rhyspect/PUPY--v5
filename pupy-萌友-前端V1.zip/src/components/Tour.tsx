import { REALMS } from '../constants';
import { motion } from 'motion/react';

export default function Tour({ onSelectRealm }: { onSelectRealm: () => void }) {
  return (
    <div className="px-6 space-y-8">
      <section className="mb-10">
        <h1 className="font-headline text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
          云端 <span className="text-primary italic">之旅</span>
        </h1>
        <p className="text-slate-500 mt-2 font-medium">选择一个领域与您的伴侣共同探索</p>
      </section>

      <div className="space-y-8">
        {REALMS.map((realm) => (
          <div 
            key={realm.id} 
            onClick={onSelectRealm}
            className="relative group cursor-pointer"
          >
            <div className="absolute inset-0 bg-primary/5 rounded-[2.5rem] blur-2xl group-hover:bg-primary/10 transition-all duration-500" />
            <div className="relative h-[240px] rounded-[2.5rem] overflow-hidden shadow-xl transition-all duration-500 group-hover:-translate-y-2 border border-slate-100">
              <img 
                src={realm.image} 
                alt={realm.name} 
                className="absolute inset-0 w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <div className="flex justify-between items-end">
                  <div className="min-w-0 flex-1">
                    {realm.active && (
                      <div className="flex items-center gap-2 mb-2">
                        <span className="px-3 py-1 bg-primary text-white rounded-full text-[10px] font-black tracking-widest uppercase shadow-lg shadow-primary/20">当前活跃</span>
                      </div>
                    )}
                    <h2 className="text-3xl font-headline font-bold text-white mb-1 truncate">{realm.name}</h2>
                    <div className="flex items-center gap-2 text-white/70">
                      <span className="material-symbols-outlined text-sm">pets</span>
                      <span className="font-bold text-xs uppercase tracking-tight">{realm.onlineCount} 位小伙伴在线</span>
                    </div>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center text-white shadow-2xl group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined text-3xl">{realm.icon}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 p-8 bg-white rounded-[2.5rem] text-center border-2 border-dashed border-slate-200 shadow-sm">
        <h3 className="font-headline font-bold text-slate-900 text-xl">私人之旅？</h3>
        <p className="text-slate-500 text-sm mt-2 mb-6 font-medium">为您和您的朋友创建一个秘密领域</p>
        <button className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-primary active:scale-95 transition-all shadow-xl shadow-slate-200 flex items-center justify-center gap-2">
          <span className="material-symbols-outlined">door_open</span>
          创建传送门
        </button>
      </div>
    </div>
  );
}
