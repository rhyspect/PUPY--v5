import { PETS } from '../constants';
import { motion } from 'motion/react';

export default function Home({ onMatch }: { onMatch: () => void }) {
  const currentPet = PETS[0];

  return (
    <div className="px-6 space-y-8">
      {/* Discovery Card */}
      <div className="relative aspect-[3/4.2] rounded-[3rem] overflow-hidden shadow-2xl bg-slate-100 group border border-slate-200">
        <img 
          src={currentPet.image} 
          alt={currentPet.name} 
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        {/* Owner Info */}
        <div className="absolute top-6 left-6 right-6 flex items-center justify-between">
          <div className="flex items-center gap-3 bg-black/30 backdrop-blur-xl px-4 py-2 rounded-full border border-white/20">
            <img src={currentPet.ownerAvatar} alt="Owner" className="w-8 h-8 rounded-full border-2 border-white/50" />
            <span className="text-white text-sm font-bold tracking-tight truncate max-w-[100px]">{currentPet.ownerName}</span>
          </div>
          <div className="flex gap-2">
            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30 cursor-pointer hover:bg-white/30 transition-colors">
              <span className="material-symbols-outlined text-xl">share</span>
            </div>
          </div>
        </div>

        {/* Pet Info */}
        <div className="absolute bottom-6 left-6 right-6 space-y-3">
          <div className="flex items-end gap-3">
            <h2 className="text-4xl font-black text-white font-headline tracking-tight truncate flex-1">
              {currentPet.name}, {currentPet.age}
            </h2>
            <div className="bg-primary text-white px-3 py-1 rounded-xl text-[10px] font-black tracking-widest uppercase mb-1 shadow-lg">
              {currentPet.mbti}
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {currentPet.tags.map(tag => (
              <span key={tag} className="bg-white/10 backdrop-blur-md text-white/90 px-3 py-1 rounded-full text-[10px] font-bold border border-white/10 tracking-wide">
                {tag}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 text-white/70 pt-2">
            <span className="material-symbols-outlined text-lg">near_me</span>
            <span className="text-xs font-bold tracking-widest uppercase">{currentPet.distance} • 活跃于 10分钟前</span>
          </div>
        </div>
      </div>

      {/* Interaction Buttons */}
      <div className="flex items-center justify-center gap-8 pb-4">
        <button className="w-20 h-20 rounded-[2.5rem] bg-white flex items-center justify-center text-slate-400 shadow-xl hover:scale-110 active:scale-90 transition-all border border-slate-100">
          <span className="material-symbols-outlined text-4xl">close</span>
        </button>
        <button 
          onClick={onMatch}
          className="w-24 h-24 rounded-[2.5rem] bg-primary text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-90 transition-all shadow-primary/30"
        >
          <span className="material-symbols-outlined text-5xl" style={{ fontVariationSettings: "'FILL' 1" }}>favorite</span>
        </button>
      </div>

      {/* Background Decoration */}
      <div className="fixed top-1/2 -right-12 -translate-y-1/2 opacity-[0.03] pointer-events-none select-none">
        <span className="text-[20rem] font-black text-primary italic tracking-tighter">PUPY</span>
      </div>
    </div>
  );
}
