import { motion } from 'motion/react';

interface ProfileProps {
  userPet: { name: string; image: string; hasPet: boolean };
  onStartCreation: () => void;
}

export default function Profile({ userPet, onStartCreation }: ProfileProps) {
  return (
    <div className="px-6 space-y-8 pb-10">
      <section className="text-center space-y-2">
        <h1 className="font-headline text-4xl font-extrabold tracking-tight text-primary">我的空间</h1>
        <p className="text-slate-500 font-medium tracking-tight">已与 {userPet.name} 同步 • 在线</p>
      </section>

      <div className="relative grid grid-cols-1 gap-4">
        {/* Human Profile */}
        <div className="bg-white rounded-[2.5rem] p-8 space-y-6 relative overflow-hidden shadow-sm border border-slate-100">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-xl rotate-3 ring-4 ring-primary/5">
              <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200" className="w-full h-full object-cover" alt="Human" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="font-headline text-2xl font-bold text-slate-900 truncate">Elena Vance</h2>
              <p className="text-primary font-bold italic text-sm">首席铲屎官</p>
              <div className="flex flex-wrap gap-2 mt-2">
                <span className="px-3 py-1 bg-primary/10 text-primary text-[10px] rounded-full font-black uppercase tracking-widest">LVL 42</span>
                <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] rounded-full font-black uppercase tracking-widest">自然漫步者</span>
              </div>
            </div>
          </div>
          <div className="flex justify-between items-center text-sm font-bold pt-6 border-t border-slate-50">
            <div className="text-center flex-1">
              <p className="text-slate-400 text-[10px] uppercase tracking-widest mb-1">散步</p>
              <p className="text-lg text-slate-900">124</p>
            </div>
            <div className="w-px h-8 bg-slate-100" />
            <div className="text-center flex-1">
              <p className="text-slate-400 text-[10px] uppercase tracking-widest mb-1">奖励</p>
              <p className="text-lg text-slate-900">890</p>
            </div>
            <div className="w-px h-8 bg-slate-100" />
            <div className="text-center flex-1">
              <p className="text-slate-400 text-[10px] uppercase tracking-widest mb-1">治愈</p>
              <p className="text-lg text-emerald-500">98%</p>
            </div>
          </div>
        </div>

        {/* Toggle Button */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
          <button className="bg-primary text-white rounded-full px-6 py-3 font-bold shadow-2xl flex items-center gap-3 hover:scale-110 active:scale-95 transition-all border-4 border-white">
            <span className="material-symbols-outlined text-xl">sync</span>
            <span className="tracking-wide text-sm">现实 / 虚拟</span>
          </button>
        </div>

        {/* Pet Profile */}
        <div className="bg-emerald-50/50 rounded-[2.5rem] p-8 space-y-6 relative overflow-hidden border border-emerald-100/50">
          <div className="flex items-center gap-6 justify-end text-right">
            <div className="flex-1 min-w-0">
              <h2 className="font-headline text-2xl font-bold text-slate-900 truncate">{userPet.name}</h2>
              <p className="text-emerald-600 font-bold italic text-sm">{userPet.hasPet ? '现实伴侣' : '云端克隆'}</p>
              <div className="flex flex-wrap gap-2 mt-2 justify-end">
                <span className="px-3 py-1 bg-white/80 text-emerald-600 text-[10px] rounded-full font-black uppercase tracking-widest shadow-sm">开心</span>
                <span className="px-3 py-1 bg-white/80 text-emerald-600 text-[10px] rounded-full font-black uppercase tracking-widest shadow-sm">饱腹</span>
              </div>
            </div>
            <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-xl -rotate-3 bg-white ring-4 ring-emerald-500/10">
              <img src={userPet.image} className="w-full h-full object-cover" alt="Pet" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-4">
            <div className="h-2 bg-white rounded-full overflow-hidden shadow-inner"><div className="h-full bg-emerald-500 w-3/4 shadow-sm" /></div>
            <div className="h-2 bg-white rounded-full overflow-hidden shadow-inner"><div className="h-full bg-emerald-500 w-1/2 shadow-sm" /></div>
            <div className="h-2 bg-white rounded-full overflow-hidden shadow-inner"><div className="h-full bg-emerald-500 w-full shadow-sm" /></div>
          </div>
          <p className="text-[10px] text-center font-black text-emerald-600/50 uppercase tracking-[0.2em]">数字生命状态监测</p>
        </div>
      </div>

      <button 
        onClick={onStartCreation}
        className="w-full py-5 rounded-[2rem] bg-slate-900 text-white font-bold text-lg shadow-xl hover:bg-primary transition-all flex items-center justify-center gap-3 active:scale-95"
      >
        <span className="material-symbols-outlined">add_circle</span>
        <span>创建新的数字克隆</span>
      </button>
    </div>
  );
}
