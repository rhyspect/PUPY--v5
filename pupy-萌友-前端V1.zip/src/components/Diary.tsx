import { motion } from 'motion/react';

export default function Diary() {
  return (
    <div className="px-6 space-y-8">
      <section className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h2 className="text-3xl font-headline font-bold tracking-tight text-slate-900">昨日社交日志</h2>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Yesterday's Log</span>
        </div>
        
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-primary/10 rounded-2xl">
              <span className="material-symbols-outlined text-primary text-2xl">neurology</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">意识同步率</p>
              <p className="text-xl font-headline font-bold text-primary">98.4% 已同步</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="relative">
                <img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&q=80&w=100" className="w-12 h-12 rounded-2xl bg-slate-100 object-cover" alt="Friend" />
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                  <span className="material-symbols-outlined text-[10px] text-white" style={{ fontVariationSettings: "'FILL' 1" }}>pets</span>
                </div>
              </div>
              <div className="flex-1 space-y-2 min-w-0">
                <p className="text-slate-900 font-bold text-lg truncate">豆豆遇到了 <span className="text-emerald-500">可乐</span></p>
                <div className="bg-slate-50 p-4 rounded-2xl rounded-tl-none border border-slate-100 shadow-inner">
                  <p className="text-sm font-mono text-slate-400 tracking-widest break-all">⟁ ⏀ ⏦ ⧉ ⏛ ... ⍙ ⎈ ⏝</p>
                  <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-widest">神经链路翻译: "嗅觉频率高 / 检测到好友"</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h2 className="text-2xl font-headline font-bold tracking-tight text-on-surface">指令面板</h2>
          <span className="text-sm font-medium text-outline">Instruction Area</span>
        </div>
        <div className="bg-surface-container-high squircle p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <span className="material-symbols-outlined text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>bolt</span>
            <h3 className="font-headline font-bold text-on-surface">同步下次行为</h3>
          </div>
          <textarea 
            className="w-full bg-white border-none rounded-2xl p-4 text-on-surface placeholder:text-outline/50 focus:ring-4 focus:ring-primary-container/20 transition-all duration-300 resize-none shadow-inner" 
            placeholder="悄悄告诉你的宠物，下次遇到 TA 该怎么办？" 
            rows={3}
          />
          <div className="mt-6 flex flex-wrap gap-2">
            <button className="px-4 py-2 bg-primary-container text-on-primary-container rounded-full text-xs font-bold hover:scale-105 transition-transform active:scale-95">🐾 表现友好</button>
            <button className="px-4 py-2 bg-secondary-container text-on-secondary-container rounded-full text-xs font-bold hover:scale-105 transition-transform active:scale-95">🎾 邀请玩耍</button>
            <button className="px-4 py-2 bg-tertiary-container text-on-tertiary-container rounded-full text-xs font-bold hover:scale-105 transition-transform active:scale-95">🤫 保持冷静</button>
          </div>
          <button className="w-full mt-6 py-4 bg-primary text-on-primary rounded-3xl font-headline font-bold text-lg shadow-lg hover:scale-[1.02] transition-transform active:scale-95 flex items-center justify-center gap-2">
            <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>upload_file</span>
            上传意识指令
          </button>
        </div>
      </section>
    </div>
  );
}
